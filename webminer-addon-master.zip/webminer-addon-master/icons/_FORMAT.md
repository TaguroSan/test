# Format

Source icons **require** the `viewBox` attribute and **must have** `fill="currentColor"`
set on their `path`, `rect`, or `circle` tags to inherit the (text-)color from their
respective parent context.

The SVG's file name is used together with the prefix `nq-` as its `id` in the sprite.
